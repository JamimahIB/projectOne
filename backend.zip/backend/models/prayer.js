const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const prayerSchema = new Schema({
  prayerTitle: {type:String, required:true},
  prayerdesc: {type:String, required:true},
  //prayerText:{type:String,required:true},
  //prayerPic:{type:String,required:true},
  image: {type:String, required: true},
  prayergroup:{type:String,required:true},
  // favoritePrayer:{type:String},
  // peoplePraying:{type:Number},
  // prayerReels:{type:String},
  // prayerStatus:{type:String},
  // prayerType:{type:String},
  creator:{ type:mongoose.Types.ObjectId, required:true, ref:'users'}
}, {timestamps:true}
);
module.exports = mongoose.model('prayers',prayerSchema);