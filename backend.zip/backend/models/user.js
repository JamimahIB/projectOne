const mongoose = require('mongoose');
const Schema =mongoose.Schema;
const uniqueValidator = require('mongoose-unique-validator');

const userSchema = new Schema({
    fullName:{
        type:String
    },
    email:{
        type:String,required:true, unique: true   
    },
    username:{
        type:String,required:true
    },
    password:{
        type: String,required:true,minLength:6
    },
    status:{
        type:String
    },
    cellNumber:{type:Number
    },
    userPicture:{type:String
    },
    // prayerId:{
    //     type:Number,
    //     required:true
    // },
    isAdmin:{
        type:Boolean
    },
    isPrayerWarrier:{
        type:Boolean
    },
    userBadgeId:{
        type:Number
    },
    token:{
        type:String,default:''
    },
    //[{ type: mongoose.Types.ObjectId, required: true, ref: 'Place'}]
   prayers:[{ type: mongoose.Types.ObjectId, required: true, ref:'prayers' }]
});
userSchema.plugin(uniqueValidator);
module.exports = mongoose.model('users', userSchema);
