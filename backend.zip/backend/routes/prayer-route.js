const express = require('express');
//const prayer_route = express();
const { check } = require('express-validator');
const prayerController = require('../controllers/prayer_controller');
//const { post } = require('./user-route');
const router = express.Router();
const path = require('path');
//prayer_route.use(express.static('public'));
const multer = require('multer');

const multerConfig = multer.diskStorage({

  destination:function(req, file, cb) { 
    cb(null,path.join(__dirname,'../public/images'),function(error,success){
      if(error){
         console.log(error);
      }
    });    
 }, 
 filename:function(req, file, cb) { 
     const name = Date.now()+'-'+file.originalname;  
     cb(null ,name,function(error,success){
      if(error){
          console.log(error);
        }
  });   
 }
});
const upload = multer({
  storage:multerConfig
})


router.post(
    '/',
   upload.single('image'),
    [
      check('prayerTitle')
      .not()
      .isEmpty(),
      check('prayerdesc')
        .not()
        .isEmpty(),
       check('prayergroup')
        .not()
        .isEmpty()  
    ],
    prayerController.createPrayer
  );
  
  module.exports = router;


