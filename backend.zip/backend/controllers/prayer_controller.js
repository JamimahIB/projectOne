const mongoose = require('mongoose');
const Prayer = require('../models/prayer');
const User = require ('../models/user');
const {validationResult} = require('express-validator');
const HttpError = require('../models/http_errors');




const getPrayerReq = async(req,res,next)=>{
  let prayers;
//let uid = 1;
  const user_id = req.param.uid;
try{
     prayers = await Prayer.findById(user_id).populate("Prayer");
}
catch(err){
    const error = new HttpError(
      'Fetching Prayers failed,Please try again later',
      500
      );
  return next(error);
    }
  res.status(201).json({data:prayers})
    
   }

// const prayerReqSend = async(req,res,next) =>{
//   const errors = validationResult(req);
//    if(!errors.isEmpty()){
//       return next(
//           new HttpError('Validation failed,entered data is incorrect.', 422)
//           );
//     }
// //const prayerdesc = req.body.prayerdesc;


// const createdPrayer = new Prayer({
//   prayerTitle:req.body.prayerTitle,
//   prayerdesc:req.body.prayerdesc,
//   image:req.file.filename,
//   prayergroup:req.body.prayergroup,
//   creator:req.body.creator
//   //imageUrl:'images/duck.jpg'
// });

// let user;
// try{

//     user = await User.findById(creator);

//  }catch(err){
//     const error = new HttpError(
//        'creating prayer failed, please try again',
//         500
//      );
//    return next (error);
//    }
// if(!user){
//   const error = new HttpError('Could not find user for provided Id',404);
//   return next (error);
//   }
//   console.log(user);  
// try {
//   const sess = await mongoose.startSession();
//   sess.startTransaction();
//   await createdPrayer.save({session:sess});
//   user.prayers.push(createdPrayer);
//   await user.save({session:sess});
//   await sess.commitTransaction();
// } catch (err) {
//   const error = new HttpError(
//     'Creating Prayer Request failed, please try again later.',
//     500
//   );
//   return next(error);
// }

// res.status(201).json({prayer:createdPrayer}); // createdUser includes the PW
// };
const createPrayer = async (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return next(
      new HttpError('Invalid inputs passed, please check your data.', 422)
    );
  }

  //const { title, description, address, creator } = req.body;

  // let coordinates;
  // try {
  //   coordinates = await getCoordsForAddress(address);
  // } catch (error) {
  //   return next(error);
  // }
  //const createdPrayer = new Prayer({
    //   prayerTitle:req.body.prayerTitle,
    //   prayerdesc:req.body.prayerdesc,
    //   image:req.file.filename,
    //   prayergroup:req.body.prayergroup,
    //   creator:req.body.creator
    //   //imageUrl:'images/duck.jpg'
    // });

  const createdPrayer = new Prayer({
      prayerTitle:req.body.prayerTitle,
      prayerdesc:req.body.prayerdesc,
      image:req.file.filename,
      prayergroup:req.body.prayergroup,
      creator:req.body.creator
    //creator
  });

  let user;
  try {
    user = await User.findById(creator);
  } catch (err) {
    const error = new HttpError('Creating prayer failed, please try again', 500);
    return next(error);
  }

  if (!user) {
    const error = new HttpError('Could not find user for provided id', 404);
    return next(error);
  }

  console.log(user);

  try {
    const sess = await mongoose.startSession();
    sess.startTransaction();
    await createdPrayer.save({ session: sess });
    user.prayers.push(createdPrayer);
    await user.save({ session: sess });
    await sess.commitTransaction();
  } catch (err) {
    const error = new HttpError(
      'Creating place failed, please try again.',
      500
    );
    return next(error);
  }

  res.status(201).json({ prayer: createdPrayer });
};

exports.getPrayerReq = getPrayerReq;
exports.createPrayer = createPrayer;