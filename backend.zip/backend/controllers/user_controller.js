//const User = require('../models/user');
const User = require('../models/user');
const {validationResult} = require('express-validator');
const HttpError = require('../models/http_errors');
const nodemailer = require('nodemailer')
const randomstring = require('randomstring');
const config = require('../config/config');
const bcrypt = require('bcryptjs');
const jwt = require("jsonwebtoken");
const getUsers = async (req,res,next)=>{
let users;

try{
    users = await User.find({},'-password');
}catch(err){
const error = new HttpError
    ('fetching user failed,please try agian later',
500
);
return next(error);
}
res.json({users:users.map(user => user.toObject({getters:true}))}); 

};
const signup = async(req,res,next) =>{
  const errors = validationResult(req);
  if(!errors.isEmpty()){
         return next(
            new HttpError('Invlaid input Passed, please check your data.', 422)
        );
    }
 const {email, username, password} = req.body;
 
 let existingUser;
 try{
 
    existingUser = await User.findOne({email:email})
 
 }catch(err){
    const error = new HttpError(
        'SignUp failed,please try again later',
        500
    );
    return next(error);
 }
 if(existingUser){
    const error = new HttpError(
        'User exist already,please login instead',
        422
    );
    return next(error);
 }
 let hashedPassword;
 try{
  hashedPassword = await bcrypt.hash(password,12);
 }catch(err){
  const error = new HttpError(
    'could not create user,please try again',
    500
  );
  return next(error);
 }
 
 const createdUser = new User({
    email,
    username,
    password:hashedPassword,
    prayers:[]
 });
 try {
    await createdUser.save();
  } catch (err) {
    const error = new HttpError(
      'Signing up failed, please try again later.',
      500
    );
    return next(error);
  }
  let token;
  try{
   token = jwt.sign({userId:createdUser.id},
    'supersecret_dont_share',{expiresIn:'1h'})
    res.cookie('access_token',token);
  }catch(err){
    const error = new HttpError(
      'Signing up failed, please try again later.',
      500
    );
    return next(error);
  }
  res.status(201).json({user:createdUser.toObject({ getters: true })});
     // res.status(201).json({userId:createdUser._id,email:createdUser.email,token:token}); // createdUser includes the PW
  };
  
const login = async (req, res, next) => {
  let token;
  const { username, password } = req.body;
   if(!username || !password){
    
    return res.status(400).json({error:'please filled the data'});
   }
 // let existingUser;

  try {
    //existingUser = await User.findOne({ username: username });
       let loginUser = await User.findOne({username:username})
  
    if(loginUser){
      const isMatch = await bcrypt.compare(password,loginUser.password);
      token = jwt.sign(
        {
          User:loginUser._id,
        },
        process.env.SECRETKEY);
     // token = await loginUser.generateAuthToken();
       console.log(token);

      
    res.cookie("jwtPW", token, {
        //expires:new Date(Date.now() + 25892000000),
        httpOnly:true,
        secure:true,
        sameSite:"none",
        })
        .send(_.pick(User,["_id","name","role"]));
      if (!isMatch) {
        const error = new HttpError(
          'Invalid credentials, could not log you in.',
          400
        );
        
      }else{
        console.log("user SignIn Successfully");
      }
    }else {
      res.status(400).json({error:"Invalid Credential"});
    }
    return next(error);
  } catch (err) {
    const error = new HttpError(
      'Loggin in failed, please try again later.',
      500
    );
  }
  
  res.status(201).json({message:'Logged In',token:token});
  };
exports.getUsers = getUsers;
exports.signup = signup; 
exports.login = login;
